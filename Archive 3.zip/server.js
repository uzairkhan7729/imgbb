#!/usr/bin/env node

var express = require("express"),
  app = express(),
  bodyParser = require('body-parser'),
  errorHandler = require('errorhandler'),
  methodOverride = require('method-override'),
  //hostname = process.env.HOSTNAME || 'localhost',
  port = 3000
publicDir = process.argv[2] || __dirname + '/public',
  path = require('path');
//const axios = require('axios');
//const FormData = require('form-data');
const imgbbUploader = require("imgbb-uploader");
//var FormData = require('form-data');
const querystring = require("querystring");
const {
  Curl
} = require("node-libcurl");
const https = require('https');
const axios = require('axios');
//const FormData = require('form-data');
const ApiClient = require('imgbb');

//const  {FormData}=require('node-fetch');
//import fetch, { FormData } from 'node-fetch';
//const parseDataUrl= require("data-uri-to-buffer");
//const axios= require("axios");
//const fetch = require('node-fetch');
const FormData = require( "form-data");

var request = require('request').defaults({
  encoding: null
});
const {
  imgbb
} = require('express-imgbb')
const API_KEY = "a12adda3c6c275267c7fc1a57bea38e6"


const bufferToBase64 = (buffer) =>
  new Promise((resolve) => {
    const buff =  Buffer.from(buffer);
    const base64string = buff.toString("base64"); // https://nodejs.org/api/buffer.html#buftostringencoding-start-end
    return setTimeout(() => {
      resolve(base64string);
    }, 1000);
  });


app.get("/", async function (req, res) {
  const files = req.query.x.split(',')
  // onst promises = tasklist.data.items.map(async t => {
  //   const task = await listTasks(t.id, req.body.cred);
  //   return task;
  // })
  // const _tasks = await Promise.all(promises);
  var urls = '';
  var count = 0;
  const promises = await files.map(async (x, index) => {
    return request.get(x, async function (error, response, body) {

      if (!error && response.statusCode == 200) {
        const data = "data:" + response.headers["content-type"] + ";base64," + Buffer.from(body).toString('base64');
      //   const imgbb = {
      //     url: "https://api.imgbb.com/1/upload", // url brindada por la API de imgBB
      //     key: "a12adda3c6c275267c7fc1a57bea38e6" // api key generada para el usuario de la cuenta
      // };
      //  uploadImageToImgbb(imgbb);
        //     console.log("reach here");
    //     const body1 = new FormData();
    // //    body1.append("key","a12adda3c6c275267c7fc1a57bea38e6")
    // body1.append("image", "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
    // //body1.append("image", "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
    // const result = await axios.get(
    //     `https://api.imgbb.com/1/upload?expiration=600&key=a12adda3c6c275267c7fc1a57bea38e6`, {
    //       body1
    //     }
    //   ).then(result => console.log("esar",result))
    //   console.log("ress", result)
  //       const buffer = parseDataUrl(dataUrl);

  // if (buffer.byteLength > 10 * 10 ** 6)
  //   throw new Error("The image exceeds the maximum size of 10 MB");

  // const body = new FormData();
  // body.append("image", buffer, "someImageName.png");

  // const result = await fetch(
  //   `https://api.imgbb.com/1/upload?key=<your-api-key>`, {
  //     method: "post",
  //     // headers: { ...body.getHeaders() },
  //     body
  //   }
  // ).then(result => result.json())
  // .then(data => {
  //   console.log(data); // Working fine here too.
  // });

  // console.log("-------result--------\n", result); // Result is fine.

  // // Logic testing.
  // console.log(result.success);
  // console.log(result.url);
  // console.log(!result.success);
  // console.log(!result.url);
  // console.log(!result.success || !result.url);


  // if (!result.success || !result.url) {
  //   const msg = result.error?.message;
  //   console.log(`There was an error during upload${msg ? `: ${msg}` : ""}`)
  //   // throw new Error(
  //   //   `There was an error during upload${msg ? `: ${msg}` : ""}`
  //   // );
  // }

  

        // console.log("imageUrl", x)
        // const imgbbUploader = require("imgbb-uploader");
        //        const options = {
        //           apiKey: 'a12adda3c6c275267c7fc1a57bea38e6', // MANDATORY
        //           imageUrl:x
        //           // OPTIONAL: pass base64-encoded image (max 32Mb)
        //         }; 
        // imgbbUploader(options)
        //   .then((response) => console.log('e',response))
        //   .catch((error) => console.error(error));


        //upload('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7','test',200)
        // const form = new FormData();
        // const file = "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"

        // form.append("image", file);
        // const response1 = await axios.post(
        //   `https://api.imgbb.com/1/upload?key=${API_KEY}`,
        //   form, {
        //     headers: form.getHeaders()
        //   }
        // );

        // console.log("as",response1);

        // const imgbb = req['imgbb']
        // const results = imgbb.results
        // let api =  ApiClient({
        //   token: 'a12adda3c6c275267c7fc1a57bea38e6',
        //  });
        //  let ret = await api.upload({
        //   /**
        //    * A binary file, base64 data, or a URL for an image. (up to 16MB)
        //    */
        //   image: 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
        //  })
        //  .catch(e => consoleDebug.red.dir(e))
        // ;

        // console.log(ret);

        // const form = new FormData();
        // form.append('image', 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');

        // const tsla = await axios.post(
        //   'https://api.imgbb.com/1/upload',
        //   {image: "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"}
        //   , {
        //     params: {
        //       'expiration': '600',
        //       'key': 'a12adda3c6c275267c7fc1a57bea38e6'
        //     },
        //     headers: {
        //       ...form.getHeaders()
        //     }
        //   }
        // );
        // console.log("ts",tsla);
        // uploadImage("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
        // const options = {
        //   //apiKey: 'a12adda3c6c275267c7fc1a57bea38e6', // MANDATORY
        //   image: 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
        //   // OPTIONAL: pass base64-encoded image (max 32Mb)
        // };
        // request.post('https://api.imgbb.com/1/upload?expiration=600&key=a12adda3c6c275267c7fc1a57bea38e6',options, async function(error, response1, body){
        //   if(!error){
        //   console.log('ers',response1)
        // console.log('b',body)
        // }
        //   else{
        //     console.log('err',error)
        //   }
        // })

        // const options = {
        //   hostname: 'https://api.imgbb.com',
        //   port: 443,
        //   path: '/1/upload?expiration=600&key=a12adda3c6c275267c7fc1a57bea38e6',
        //   method: 'Post',
        //   body:{
        //     image: 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
        //   }
        // };

        // const req = https.request(options, res => {
        //   console.log(`statusCode: ${res.statusCode}`);

        //   res.on('data', d => {
        //     console.log(d);
        //   });
        // });

        // req.on('error', error => {
        //   console.error(error);
        // });

        // req.end();
         const curlTest = new Curl();

        curlTest.setOpt(Curl.option.URL, "https://api.imgbb.com/1/upload?expiration=600&key=46cc3a904098ae19e029bca500442f8a");
        curlTest.setOpt(Curl.option.POST, true);
        curlTest.setOpt(
          Curl.option.POSTFIELDS,
          querystring. stringify({
            image: await bufferToBase64(body),
          })
        );
        curlTest.on("end", function (statusCode, data, headers) {
          console.info("Status code " + statusCode);
          console.info("***");
          const ob=JSON.parse(data);
          console.log(index)
          if(count==0){
            urls+=ob.data.url ;
            count++;
          }else{
            urls+='##'+ob.data.url 
          }

          console.log("obj",ob)

          console.info("Our response: " + data);
          console.info("***");
          console.info("Length: " + data.length);
          console.info("***");
          console.info("Total time taken: " );

          this.close();
          
        });
        curlTest.perform();
        
      //  const form = new FormData();
        // form.append('image', data);

        // const response1 = await axios.post(
        //   'https://api.imgbb.com/1/upload',
        //   form, {
        //     params: {
        //       'expiration': '600',
        //       'key': 'a12adda3c6c275267c7fc1a57bea38e6'
        //     },
        //     headers: {
        //       ...form.getHeaders()
        //     }
        //   }
        // );
        // urls.push("image",response1.data);
        // console.log('-->',response1);


        // const form = new FormData();
        // form.append('image', 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');

        // fetch('https://api.imgbb.com/1/upload?expiration=600&key=a12adda3c6c275267c7fc1a57bea38e6', {
        //   method: 'POST',
        //   body: form
        // });
        //   var options = {
        //     url: 'https://api.imgbb.com/1/upload?expiration=600&key=a12adda3c6c275267c7fc1a57bea38e6',
        //     method: 'POST'
        // };

        // function callback(error, response, body) {
        //     if (!error && response.statusCode == 200) {
        //         console.log(body);
        //     }
        // }

        // request(options, callback);
        // const imgbbUploader = require("imgbb-uploader");
        //        const options = {
        //           apiKey: 'a12adda3c6c275267c7fc1a57bea38e6', // MANDATORY
        //           base64string:'iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAEklEQVR42mNcLVNbzwAEjDAGACcSA4kB6ARiAAAAAElFTkSuQmCC'
        //           // OPTIONAL: pass base64-encoded image (max 32Mb)
        //         }; 
        // imgbbUploader(options)
        //   .then((response) => console.log('e',response))
        //   .catch((error) => console.error(error));
        // let payload = new FormData()
        // payload.append('image', data);
        // axios.post('https://api.imgbb.com/1/upload?key=a12adda3c6c275267c7fc1a57bea38e6', payload)
        //   .then((response) => {
        //     console.log('response', response)
        //     console.log('response URL', response.data.data)
        //     console.log('success')
        //   })
        //   .catch((error) => {
        //     console.log('error', error)
        //     //alert('try agian')
        //   })
        // const options = {
        //   apiKey: 'a12adda3c6c275267c7fc1a57bea38e6', // MANDATORY
        //   base64string:data
        //   // OPTIONAL: pass base64-encoded image (max 32Mb)
        // };
        // request.post('https://api.imgbb.com/1/upload',options, async function(error, response1, body){
        //   if(!error){
        //   console.log('ers',response1)}
        //   else{
        //     console.log('err',error)
        //   }
        // })
        //console.log('data', data);
        //  uploadImage(data);

        // await imgbbUploader(options)
        //   .then((response) => console.log(response))
        //   .catch((error) => console.error(error));
        // return data;
      }
    });
    // console.log("aassss", data);
return data;

  })
  const _data= await Promise.all(promises).then(()=>{
    
  });
  // console.log('sss', _data)

  //console.log('files',files)
  setTimeout(() => {
    console.log("urks", urls)
    res.send(urls)
  }, 10000);

});

async function uploadImage(img) {
  let body = {
    image: img
  }
  //body.append('key', 'a12adda3c6c275267c7fc1a57bea38e6')
  // body.append('image', img)

  const ac = await axios({
    method: 'post',
    url: 'https://api.imgbb.com/1/upload?expiration=600&key=a12adda3c6c275267c7fc1a57bea38e6',
    data: body
  })
  console.log('as', ac);
}
async function upload(image, name = '', expiration = 0) {
  const query = { key: 'a12adda3c6c275267c7fc1a57bea38e6' }

  if (name) query.name = name
  if (expiration) query.expiration = expiration

  const url = 'https://api.imgbb.com/1/upload'
  const result = await axios.post(url, JSON.stringify({ image }))
  console.log("resss",result)
  return result.data.data
}

const uploadImageToImgbb = async ({ url, key }) => { // este metodo es el que envia la solicitud y por ende sube la imagen, headers es la cabecera del contenido y en este caso es multipart/form-data
  try {
      const URL = `${url}?key=${key}`; // url de la API y se envia como valor atraves de la url la llave maestra podriamos decir, bajo la clave de key y su valor es un string similar a un token
      const formData = new FormData();
      formData.append("name", 'asd');
      formData.append("image", 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
      ///const formData = prepareImage(image);
      querystring.stringify({
        'image': 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
      })
      const config = { headers: { Accept: "application/json", "content-type": "multipart/form-data" } };
      const reult=await axios.post(URL, querystring.stringify({
        image: 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
      }), config); // mandamos la solicitud atraves de post ya que vamos de cierto modo a insertar una imagen en nuestra cuenta imgBB
      console.log(reult); // respuesta de la solicitud
        console.log(reult.data.data.url); 
      console.log("res",reult)
      return reult
  } catch (error) {
      throw error;
  }
};
//https://api.imgbb.com/1/upload
//key
//image
//a12adda3c6c275267c7fc1a57bea38e6
//https://test-man.imgbb.com/
// app.use(methodOverride());
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({
//   extended: true
// }));
// app.use(express.static(publicDir));
// app.use(errorHandler({
//   dumpExceptions: true,
//   showStack: true
// }));

console.log("Simple static server showing %s listening at http://%s:%s", publicDir, port);
app.listen(port);